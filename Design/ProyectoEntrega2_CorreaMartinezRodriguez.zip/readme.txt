Readme 

Este directorio contiene la segunda entrega del proyecto del curso Bases de Datoa presentado por los estudiantes 
Daniel Correa 1225622 
Brayan Rodriguez 1225796 
Alvaro Martinez 1222904 

Aqui puede encontrar los archivos: 
- Modelo ER: El modelo entidad relacion corregido de acuerdo a las modificaciones del proyecto
- Modelo Relacional : El modelo relacional corregido de acuerdo a las modificaciones del proyecto
- clinica.sql : Archivos sql con la base de datos del proyecto , contiene los drop table comentados
- Demostracion3FN : Documento justificando que la base de datos se encuentra en tercera forma normal 
- readme.txt : Archivo de instrucciones sobre esta entrega del proyecto 


